add config copy to exp folder!
    + model and dataset files?
    save as checkpoint!
data statistics! Split test
EVALUATION
LOAD MODEL AND DEPLOY!